---
id: 113
title: "Felszín alatti víz szennyezettségi ábrái a Szövőgyár utcai záródokumentációhoz: 5_21_indeno_1_2_3_cd.pdf"
date: "2026.09.04."
author: "BPXV Önkormányzat"
recipient: "IV. és XV. kerületi lakosság"
summary: "A korábban közzétett törzsanyag után most a Szövőgyár utca 19–21. szám alatti ingatlanon és környezetében feltárt szennyezettségről készült kiegészítő tényfeltárási záródokumentáció mellékleteit, függelékeit és táblázatait is közzéteszi az önkormányzat."
source_url: "https://www.bpxv.hu/sites/default/files/media/file/2026/09/5_21_indeno_1_2_3_cd.pdf"
original_filename: "5_21_indeno_1_2_3_cd.pdf"
case_number: "0393"
---
![img-0.jpeg](img-0.jpeg)

# Jelmagyarázat

PAH, Indeno(1,2,3-cd)pirén FAV mintavételi pont, jellemző értékkel

Meglévő, emberi jelenlétet igénylő tevékenységgel érintett, ipari célú épület (iroda, raktár)

Meglévő, használaton kívüli, emberi jelenlétet nem érintett épület

Egykori gyárépület, amely felszín felett lebontásra került, az alapjai a földben vannak

Lakott lakóépület

Lakóházhoz tartozó melléképület, tartós emberi tartózkodás nélküli funkcióval

Intézményi területen található, tartós emberi tartózkodással érintett épület (Óvoda, Leánynevelő Intézet)

# Ábra azonosító

Érintett közeg: felszín alatti víz
Érintett anyagcsoport: Indeno(1,...)pirén
Érintett mélység: 7,0-10,0 mfa

# Szennyezettség (µg/dm³)

![img-1.jpeg](img-1.jpeg)

|  Adept Enviro Kft. 1111 Budapest, Lágymányosi u. 12. www.adeptenviro.hu  |   |   |
| --- | --- | --- |
|  Budapest XV., volt Rákospalotai Finomkötöttárugyár környezetének áttekintő helyszínrajza  |   |   |
|  Kiegészítő TZD, 2. ütem + MBT Szennyezettség elterjedési ábrák - felső szint  |   |   |
|  Témavezető: Kapui Zsuzsanna | Mérőarány: 1:2000 | Munkaszám: 0393  |
|  Szerkesztette: Takus András | Dátum: 2005. április | Ábraszám: 5.21  |