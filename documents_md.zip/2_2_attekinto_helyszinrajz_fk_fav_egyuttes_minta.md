---
id: 113
title: "A Szövőgyár utcai szennyezettségről készült kiegészítő tényfeltárási záródokumentáció ábrái: 2_2_attekinto_helyszinrajz_fk_fav_egyuttes_minta.pdf"
date: "2026.09.04."
author: "BPXV Önkormányzat"
recipient: "IV. és XV. kerületi lakosság"
summary: "A korábban közzétett törzsanyag után most a Szövőgyár utca 19–21. szám alatti ingatlanon és környezetében feltárt szennyezettségről készült kiegészítő tényfeltárási záródokumentáció mellékleteit, függelékeit és táblázatait is közzéteszi az önkormányzat."
source_url: "https://www.bpxv.hu/sites/default/files/media/file/2026/09/2_2_attekinto_helyszinrajz_fk_fav_egyuttes_minta.pdf"
original_filename: "2_2_attekinto_helyszinrajz_fk_fav_egyuttes_minta.pdf"
case_number: "0383"
lot_numbers: ["88323"]
---
![img-0.jpeg](img-0.jpeg)

# Jelmagyarázat

- 2023-ban létesített mintavételi pontok, melyek jelenleg is üzemelnek
- 2024-ben létesített mintavételi pontok
- 2025, I. szakaszban létesített mintavételi pontok
- 2025, II. szakaszban elkészült mintavételi pontok
- Bp. XV. 88323 hrsz. (forrásterület)

![img-1.jpeg](img-1.jpeg)

|  Adept | Adept Enviro Kft. 1111 Budapest, Lágymányosi u. 12. www.adeptenviro.hu  |
| --- | --- |
|  Egykori Budapesti Finomkötöttárugyár II. sz. gyártelepe, Bp. XV. Szövőgyár utca 19-21.  |   |
|  Kiegészítő tényfeltárás, áttekintő helyszínrajz Víz és földtani közeg együttes mintavételi pontok  |   |
|  Témavezető: Melegh Csongor | Mérsőarány: 1:12.000  |
|  Szerkesztette: Tekus András | Dátum: 2026. január  |
|   | Munkaszám: 0383  |
|   | Ábrázsám: 2.2  |