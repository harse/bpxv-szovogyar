---
id: 113
title: "Talajszennyezettségi ábrák a Szövőgyár utcai záródokumentációhoz: 4_8_6_talaj_vocl.pdf"
date: "2026.09.04."
author: "BPXV Önkormányzat"
recipient: "IV. és XV. kerületi lakosság"
summary: "A korábban közzétett törzsanyag után most a Szövőgyár utca 19–21. szám alatti ingatlanon és környezetében feltárt szennyezettségről készült kiegészítő tényfeltárási záródokumentáció mellékleteit, függelékeit és táblázatait is közzéteszi az önkormányzat."
source_url: "https://www.bpxv.hu/sites/default/files/media/file/2026/09/4_8_6_talaj_vocl.pdf"
original_filename: "4_8_6_talaj_vocl.pdf"
case_number: "0383"
---
![img-0.jpeg](img-0.jpeg)

# Jelmagyarázat

- + VOCI FK mintavételi pont, vizsgálati eredménnyel
- Meglévő, emberi jelenlétet igénylő tevékenységgel érintett, ipari célú épület (iroda, raktár)
- Meglévő, használaton kívüli, emberi jelenléttel nem érintett épület
- Egykori gyárépület, amely felszín felett lebontásra került, az alapjai a földben vannak
- Lakott lakóépület
- Lakóházhoz tartozó melléképület, tartós emberi tartózkodás nélküli funkcióval
- Intézményi területen található, tartós emberi tartózkodással érintett épület (Óvoda, Leánynevelő Intézet)

# Ábra azonosító

Érintett közeg: földtani közeg

Érintett anyagcsoport: VOCI

Érintett mélység:

108-107 mBf, azaz kb. 6,0 mfa

# Szennyezettség (mg/kg)

![img-1.jpeg](img-1.jpeg)

|  Adept Enviro Kft. 1111 Budapest, Lágymányosi u. 12. Fszt. 2. www.adeptenviro.hu | Budapest volt Szövőgyár (Colortex) Részletes helyszínrajz  |   |
| --- | --- | --- |
|  Kiegészítő TZD, 2. ütem + MBT Szennyezettség elterjedési ábrák  |   |   |
|  Témavezető: Melegh Csongor | Mérőtartány: 1-6500 | Munkaszám: 0383  |
|  Szerkesztette: Vámosi Oszkár | Dátum: 2026. április | Ábrászám: 4.8.6.  |